import {art} from './story-art.mjs?v=onboarding-25';
import {QUESTIONS, ROUTE, STORAGE_KEY, VERSION, choiceLabel, entryFor, profileFor, weekFor, commercialPlans, coverAngles, pauseFor, planFor, planText, question, reachable, restore} from './engine.mjs?v=onboarding-25';

const main = document.getElementById('main');
const dialog = document.getElementById('info');
const esc = text => String(text).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const params = new URLSearchParams(location.search);
const angle = params.get('angle');
const plans = commercialPlans(window.BRAINY_OFFER);
const preview = !plans.length && params.get('offer') === 'preview';
let selectedPlan = 0;
const cover = Object.hasOwn(coverAngles,angle) ? coverAngles[angle] : coverAngles.default;
const arrow = '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 12h15m-6-6 6 6-6 6"/></svg>';
const paths = {
  leaf:'M5 19c0-6 4-11 12-14m-2 12c-3 3-7 2-10 2-1-4-1-8 2-11 3-3 8-4 13-4 0 5-1 10-5 13Z',
  finish:'M5 21V4m1 1c4-4 7 3 13-1v10c-5 4-9-3-13 0',
  sun:'M12 2v2m0 16v2M2 12h2m16 0h2M5 5l1.5 1.5m11 11L19 19M5 19l1.5-1.5m11-11L19 5M17 12a5 5 0 1 1-10 0 5 5 0 1 1 10 0Z',
  star:'m12 2.8 2.7 5.5 6 .9-4.4 4.3 1.1 6.1L12 16.7l-5.4 2.9 1-6.1-4.3-4.3 6-.9Z'
};
const icon = name => '<svg viewBox="0 0 24 24" width="27" height="27" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="'+paths[name]+'"/></svg>';
const button = (label, action, disabled=false) => '<button class="primary" type="button" data-act="'+action+'"'+(disabled?' disabled':'')+'>'+label+arrow+'</button>';
const back = '<button class="back" type="button" data-act="back">'+arrow+' Back</button>';
const tag = label => '<p class="kicker">'+label+'</p>';
const section = (label,count) => '<div class="topline">'+back+'<span>'+label+(count?' <b>/</b> '+count:'')+'</span></div>';
const tour = params.get('tour')==='1';
const storage = () => tour ? sessionStorage : localStorage;
const key = tour ? 'brainy.onboarding.review' : STORAGE_KEY;
let raw = null;
try {
  if (!tour || (location.hash && location.hash!=='#cover')) raw=storage().getItem(key);
} catch {}
let {screen, answers, resumeAt} = restore(raw);
let picked = null;
let correction = null;
let standalonePreview = preview && location.hash === '#offer' && !planFor(answers);
const save = () => { if (standalonePreview) return; try { storage().setItem(key,JSON.stringify({version:VERSION,screen,answers,resumeAt})); } catch { /* The session still works in memory. */ } };
const updateAddress = (method,id) => history[method]({brainy:id},'',location.pathname+location.search+'#'+id);

const chapters = ['Meet Brainy','Your family','Your starting point','Your first session'];
function strip() {
  const i=ROUTE.indexOf(screen);
  const chapter=chapters[i<7?0:i<15?1:i<21?2:3];
  return '<div class="story-nav">'+back+'<div class="story-meter" role="progressbar" aria-label="Onboarding progress" aria-valuemin="1" aria-valuemax="25" aria-valuenow="'+(i+1)+'"><i style="width:'+((i+1)*4)+'%"></i></div><span>'+chapter+'</span></div>';
}
function panel(title,body,content,action,extra='') {
  return '<section class="journey">'+strip()+'<div class="story-page"><div class="story-head"><h1 id="question-title">'+esc(title)+'</h1><p>'+esc(body)+'</p></div><div class="story-content">'+content+'</div><div class="story-actions">'+action+extra+'</div></div></section>';
}
function coverView() {
  const started = !!answers.goal || (resumeAt && !['cover','welcome'].includes(resumeAt));
  const ready=entryFor(answers,resumeAt)==='result';
  const primary=button(started?(ready?'View my family plan':'Continue onboarding'):'Get started',started?'start':'begin');
  const again=started?'<button class="text-button" data-act="restart-prompt">Start a new quiz</button>':'';
  return '<section class="journey intro"><div class="story-page"><div class="story-head">'+tag('For parents of children ages 4–10')+'<h1 id="question-title">'+esc(cover.title)+'</h1><p>'+esc(cover.body)+'</p></div><div class="story-content">'+art('done')+'</div><div class="story-actions">'+primary+again+'</div></div></section>';
}
function quizView(q) {
  return panel(q.title,q.hint,'<fieldset class="single-pick"><legend class="sr-only">'+esc(q.title)+'</legend>'+q.options.map(o=>
    '<label class="answer"><input type="radio" name="choice" value="'+o.value+'"'+(picked===o.value?' checked':'')+'><span class="radio-mark"></span><span>'+esc(o.label)+'</span></label>'
  ).join('')+'</fieldset>',button(q.id==='moment'?'Build my family plan':'Continue','accept',!picked));
}
function sceneView() {
  const p=planFor(answers);
  const scenes={
    welcome:['Meet Brainy.','This little companion grows as your child practices new skills. Try one round the way your child would.','welcome','How does Brainy grow?'],
    feed:['Ever heard “just one more”?','When another video starts on its own, a child has to interrupt something to stop. A game with a last move gives you both a different ending.','feed','Try a last move'],
    reward:['One round ends here.','Your child would earn a Star here. They can save Stars for a game, a cartoon, or something for Brainy. The next activity waits for a choice.','reward','Continue'],
    personalize:['Let’s make this fit your child.','Think about one child and one ordinary day at home. Your answers will shape a first activity, a stopping cue, and what to do afterward.','welcome','Personalize our routine'],
    parent:['See what your child practiced.','Your parent view shows which skills your child used. A shape-matching game gives you something more specific to ask about than minutes on a screen.','report','See a first-session example'],
    benefits:['What comes with Brainy?','Your child has a place to learn and play. You choose how that fits into family life.','done','Choose our first session']
  };
  if (screen==='growth') return panel('Watch Brainy grow.', 'Slide through three example stages. As your child practices, their companion changes with them.', '<div class="growth-demo">'+art('welcome')+'<label for="stage-range">Brainy’s growth <output id="growth-label" for="stage-range">Just starting</output></label><input id="stage-range" type="range" min="1" max="3" value="1" aria-valuetext="Just starting"></div>',button('Continue','next'));
  if (screen==='pause') {const note=pauseFor(answers);return panel(note.title,note.body,art(answers.content==='clips'||answers.content==='kids'?'feed':'progress'),button('Continue','next'));}
  if (screen==='week') {
    const w=weekFor(answers.duration);
    return panel('Picture an ordinary week.',w.body,'<div class="week-note"><strong>'+esc(w.title)+'</strong><div class="week-days" aria-hidden="true">'+['M','T','W','T','F','S','S'].map(day=>'<span>'+day+'</span>').join('')+'</div></div>',button('Continue','next'));
  }
  if (screen==='example') return panel('What could that sound like?', 'For a child who starts with '+({clips:'short clips',kids:'YouTube Kids',shows:'cartoons',games:'games',other:'a mix of activities',none:'an occasional screen turn'})[answers.content]+', try saying this before you begin.', '<blockquote class="cue">'+esc(p.cue)+'</blockquote><p class="sample-after">'+esc(p.steps[3].body)+'</p>',button('Continue','next'));
  if (screen==='match') return panel('Can you find its match?', 'Try the last move in a shape game. Pick the tile that matches the card.',art('game')+'<div class="shape-choices">'+['Circle','Diamond','Triangle'].map(v=>'<button type="button" data-shape="'+v+'"><i aria-hidden="true" class="tile-'+v.toLowerCase()+'"></i>'+v+'</button>').join('')+'</div><p id="shape-feedback" class="shape-feedback" role="status"></p>','<button class="text-button" data-act="next">Skip this example</button>');
  const [title,body,scene,cta]=scenes[screen];
  const benefits = screen==='benefits'?'<ul class="feature-list"><li><strong>Learning comes first.</strong> Games earn Stars to spend on digital treats.</li><li><strong>Real life counts.</strong> Approve off-screen tasks. Your child earns Suns toward gifts you choose.</li><li><strong>You set the boundaries.</strong> Use your device’s parental controls to keep Brainy in reach during playtime.</li></ul>':'';
  return panel(title,body,benefits || art(scene),button(cta,'next'));
}

function profileView() {
  const p = profileFor(answers);
  const recap='<details id="profile-answers"><summary>See or change my answers</summary><dl class="recap">'+QUESTIONS.map(q=>'<div><dt>'+esc(q.title)+'</dt><dd>'+esc(choiceLabel(q.id,answers[q.id]))+' <button type="button" class="text-button" data-review-q="'+q.id+'" aria-label="Change answer: '+esc(q.title)+'">Change</button></dd></div>').join('')+'</dl></details>';
  return panel(p.title+'.',p.why,art('progress')+'<div class="profile-tip"><strong>Try this first</strong><p>'+p.lever+'</p></div>'+recap,button('That fits','next'),'<button class="text-button" data-act="review">I want to change an answer</button>');
}
function methodView() {
  const p=planFor(answers);
  return panel(p.feature+'.',p.benefit,art(answers.goal==='offline'?'done':answers.goal==='learning'?'reward':'progress')+'<p class="profile-tip">'+p.steps[2].body+'</p>',button('Continue','next'));
}
function resultView() {
  const p=planFor(answers);
  return '<section class="shell stage focus-stage">'+strip()+
    '<div class="result-head">'+tag('Your first session')+'<h1>'+esc(p.title)+'.</h1><p class="deck">'+esc(p.intro)+'</p><div class="result-meta"><span>Ages '+p.age+'</span><span>'+esc(p.moment)+'</span></div></div>'+
    '<div class="focus-card insight-card"><h2>What you can say</h2><blockquote>'+esc(p.cue)+'</blockquote><ol class="routine">'+p.steps.map(step=>'<li><strong>'+step.label+'</strong><p>'+step.title+' '+step.body+'</p></li>').join('')+'</ol>'+
    '<div class="check-note"><strong>Afterward, notice one thing</strong><p>'+esc(p.check)+'</p></div>'+
    '<div class="end-action">'+button('See family membership options','next')+'<button class="text-button" data-act="edit">Change my answers</button></div></div></section>';
}

const previewPlans = [
  {label:'Monthly',price:'Price pending',terms:'Monthly billing terms are pending.'},
  {label:'Annual',price:'Price pending',terms:'Annual billing terms are pending.'}
];
function billingChoices(list) {
  if (list.length <= 1) return '';
  return '<fieldset class="offer-options"><legend>Billing options</legend>'+list.map((o,i)=>'<label class="answer"><input type="radio" name="billing" value="'+i+'"'+(i===selectedPlan?' checked':'')+'><span class="radio-mark"></span><span>'+esc(o.label)+'</span></label>').join('')+'</fieldset>';
}
function billingDetail() {
  const list = plans.length ? plans : previewPlans;
  const offer = list[selectedPlan];
  return '<h2>'+esc(offer.price)+'</h2><p>'+esc(offer.terms)+'</p>'+(!plans.length?'':'<a class="primary" href="'+esc(offer.checkoutUrl)+'">Continue to checkout'+arrow+'</a>');
}
function offerView() {
  const p = planFor(answers);
  const intro = p ? 'Your first session: '+p.moment.toLowerCase()+'. Your focus is '+p.focus+'.' : 'Choose learning activities with clear endings and give your child something to look forward to off-screen.';
  const feature = p || {feature:'A visible stopping point',benefit:'Each learning game ends with a choice to stop. After three games, Brainy suggests a break.'};
  const options = plans.length ? plans : previewPlans;
  const status = plans.length ? '' : '<p class="preview-note">US enrollment is not open yet. Pricing and renewal terms are pending.</p>';
  const keepPlan = p ? (plans.length?'<button class="text-button" data-act="download">Download my family plan</button>':button('Download my family plan','download'))+'<button class="text-button" data-act="copy">Copy plan text</button>' : button('Take the parent quiz','from-preview');
  const purchase = '<p class="small-label">'+(preview?'Billing layout preview':'Family membership')+'</p>'+status+
    billingChoices(options)+'<div id="billing-detail" aria-live="polite">'+billingDetail()+'</div>'+keepPlan;
  return '<section class="shell stage">'+strip()+'<div class="offer-spread"><div>'+tag('The Brainy family membership')+
    '<h1>Make this your family’s <em>screen-time routine.</em></h1><p class="deck">'+intro+'</p><div class="offer-benefits"><div>'+icon('finish')+'<p><strong>'+feature.feature+'</strong>'+feature.benefit+'</p></div><div>'+icon('leaf')+'<p><strong>Your view as a parent</strong>See which activities your child returns to, how long sessions last, and how their Brainy changes.</p></div></div></div>'+
    '<aside class="offer-card">'+purchase+'<p id="action-feedback" class="feedback" role="status"></p></aside></div></section>';
}

function outsideView() {
  return '<section class="shell stage">'+section('Age range','Brainy for families')+'<div class="simple">'+tag('Ages 4–10')+'<h1>Brainy is designed for ages 4–10.</h1><p class="deck">The questions and activities in this guide are written for those years. If you’re thinking about another child, you can change the age range.</p>'+button('Choose a different age','back')+'</div></section>';
}

function record(event, step=screen) {
  const detail = {event, step, angle:Object.hasOwn(coverAngles,angle) ? angle : 'default'};
  window.dispatchEvent(new CustomEvent('brainy:funnel', {detail}));
}
function render(moveFocus=true) {
  const q = question(screen);
  const renderers = {cover:coverView, profile:profileView, result:resultView, method:methodView, offer:offerView, outside:outsideView};
  picked = q ? (q.options.some(o=>o.value===answers[q.id])?answers[q.id]:null) : null;
  main.innerHTML = q ? quizView(q) : (renderers[screen] || sceneView)();
  document.body.dataset.screen = screen;
  record('step_viewed');
  document.title = main.querySelector('h1').textContent+' · Brainy';
  if (moveFocus) {
    window.scrollTo(0,0);
    const title = main.querySelector('h1');
    title.tabIndex = -1;
    title.focus({preventScroll:true});
  }
}
function go(target,{replace=false}={}) {
  const next = reachable(target,answers);
  if (next === screen) return;
  if (standalonePreview) { standalonePreview = false; if (next !== 'cover') resumeAt = next; }
  else if (next === 'cover') resumeAt = screen;
  else resumeAt = next;
  screen = next;
  updateAddress(replace?'replaceState':'pushState',screen);
  save(); render();
}
const next = () => go(ROUTE[ROUTE.indexOf(screen)+1]);
function modal(title,body,actions='') {
  dialog.querySelector('.dialog-content').innerHTML = '<div class="dialog-bar"><span class="small-label">Brainy</span><button class="dismiss" aria-label="Close dialog" data-act="dismiss">×</button></div><h2 id="dialog-title">'+title+'</h2>'+body+actions;
  if (!dialog.open) dialog.showModal();
}
function download() {
  const url = URL.createObjectURL(new Blob([planText(answers)],{type:'text/plain;charset=utf-8'}));
  const a = document.createElement('a');
  a.href=url; a.download='brainy-family-starting-plan.txt'; document.body.append(a); a.click(); a.remove();
  setTimeout(()=>URL.revokeObjectURL(url),60000);
  document.getElementById('action-feedback').textContent = 'Your plan is ready to save as a text file.';
}
async function copy() {
  const text = planText(answers);
  try {
    await navigator.clipboard.writeText(text);
    document.getElementById('action-feedback').textContent = 'Plan copied to your clipboard.';
  } catch {
    modal('Copy your starting plan','<label for="plan-text">Select the text and use your device’s Copy command.</label><textarea id="plan-text" readonly>'+esc(text)+'</textarea>');
    const field=dialog.querySelector('textarea'); field.focus(); field.select();
  }
}

document.addEventListener('input',e=>{
  if (e.target.id!=='stage-range') return;
  const name=['Just starting','Growing','Grown'][Number(e.target.value)-1];
  document.getElementById('growth-label').textContent=name;
  e.target.setAttribute('aria-valuetext',name);
  e.target.closest('.growth-demo').style.setProperty('--growth-size', [0.58,0.80,1][Number(e.target.value)-1]);
});
document.addEventListener('change',e=>{
  if(e.target.matches('input[name="choice"]')) { picked=e.target.value; main.querySelector('[data-act="accept"]').disabled=false; return; }
  if (e.target.matches('input[name="billing"]')) {
    const i = Number(e.target.value);
    if (!(plans.length ? plans : previewPlans)[i]) return;
    selectedPlan = i; document.getElementById('billing-detail').innerHTML = billingDetail(); return;
  }
});
function pickAnswer(value) {
  const id=screen;
  if (!choiceLabel(id,value)) return;
  answers[id]=value;
  record('answer_selected',id);
  const returnToProfile = correction===id;
  correction=null;
  if (id==='age' && value==='outside') { go('outside'); return; }
  go(returnToProfile?'profile':ROUTE[ROUTE.indexOf(id)+1]);
}
document.addEventListener('click',e=>{
  const shape=e.target.closest('[data-shape]');
  if (shape) {
    if (shape.dataset.shape==='Diamond') { record('demo_completed'); next(); }
    else document.getElementById('shape-feedback').textContent='Look for four straight sides and four corners. Try the diamond.';
    return;
  }
  if (e.target.closest('.skip')) { e.preventDefault(); main.focus(); return; }
  if (e.target.closest('.wordmark')) { e.preventDefault(); correction=null; go('cover'); return; }
  if (e.target.closest('#billing-detail a')) record('checkout_clicked');
  const edit=e.target.closest('[data-review-q]');
  if (edit) { correction=edit.dataset.reviewQ; go(correction); return; }
  const action=e.target.closest('[data-act]')?.dataset.act;
  if (!action) return;
  if (action==='from-preview') go('cover');
  if (action==='accept' && picked) pickAnswer(picked);
  if (action==='begin') go('welcome');
  if (action==='start') go(entryFor(answers,resumeAt));
  if (action==='next') { if (screen==='match') record('demo_revealed'); if (screen==='profile') record('profile_confirmed'); next(); }
  if (action==='review') {
    record('profile_review_requested');
    const details = document.getElementById('profile-answers');
    details.open=true;
    details.querySelector('[data-review-q]').focus();
  }
  if (action==='back' && correction===screen) { correction=null; go('profile'); return; }
  if (action==='back') go(standalonePreview?'cover':screen==='outside'?'age':ROUTE[ROUTE.indexOf(screen)-1]||'cover');
  if (action==='edit') go('profile');
  if (action==='download') download();
  if (action==='copy') copy();
  if (action==='about') modal('About Brainy','<p>Brainy is a web-based learning and play space for children ages 4–10. This parent quiz helps you choose a starting activity, a stopping cue, and something to do afterward.</p><p>Parents can use their device’s own restrictions to limit access to other apps and sites.</p>');
  if (action==='restart-prompt') modal('Start a new family quiz?','<p>This will replace the answers saved in this browser.</p>',button('Start a new quiz','reset')+'<button class="text-button" data-act="dismiss">Keep my answers</button>');
  if (action==='privacy') modal('Your quiz data','<p>This quiz saves your answers in this browser so you can pick up where you left off. It doesn’t ask for a name, email address, or child account.</p><p>Starting over clears your saved answers on this device.</p>',button('Clear answers and start over','reset'));
  if (action==='dismiss') dialog.close();
  if (action==='reset') {
    dialog.close(); correction=null; answers={}; screen='cover'; resumeAt='welcome'; try { storage().removeItem(key); } catch {}
    updateAddress('replaceState','cover'); render(); document.getElementById('notice').textContent='Your quiz answers have been cleared.';
  }
});
dialog.addEventListener('click',e=>{ if(e.target===dialog){const r=dialog.getBoundingClientRect(); if(e.clientX<r.left || e.clientX>r.right || e.clientY<r.top || e.clientY>r.bottom)dialog.close();} });
function addressChanged() {
  const requested=location.hash.slice(1)||'cover';
  if (preview && requested==='offer' && !planFor(answers)) { standalonePreview=true; screen='offer'; render(); return; }
  correction=null;
  const returningFromPreview=standalonePreview;
  standalonePreview=false;
  const id=reachable(requested,answers);
  if (id!==requested) updateAddress('replaceState',id);
  if (id===screen) return;
  if (id==='cover') { if (!returningFromPreview) resumeAt=screen; } else resumeAt=id;
  screen=id; save(); render();
}
window.addEventListener('popstate',addressChanged);
window.addEventListener('hashchange',addressChanged);
if (standalonePreview) screen='offer';
else screen=location.hash ? reachable(location.hash.slice(1),answers) : 'cover';
updateAddress('replaceState',screen);
save(); render(false);
