const mascot = '<img class="sa-mascot" src="./assets/brainy-mascot.svg?v=lavender-1" alt="" width="280" height="268">';
const twinkles = '<i class="sa-glint sa-glint-a"></i><i class="sa-glint sa-glint-b"></i><i class="sa-glint sa-glint-c"></i>';
const sky = '<i class="sa-arc sa-arc-back"></i><i class="sa-arc sa-arc-front"></i>';
const coin = '<i class="sa-coin"><i class="sa-star"></i></i>';

const scenes = {
  welcome: {
    label: 'Brainy standing on a lavender hill under a starry sky.',
    picture: sky + twinkles + mascot,
  },
  game: {
    label: 'Your target is a violet diamond.',
    picture: '<div class="sa-game-stack"><i></i><i></i><div class="sa-target"><span class="sa-diamond"></span></div></div>',
  },
  reward: {
    label: 'Brainy with a gold Star earned by completing a learning game.',
    picture: '<i class="sa-reward-ring"></i>' + twinkles + mascot + coin,
  },
  feed: {
    label: 'One video ends while more videos are already lined up underneath.',
    picture: '<div class="sa-feed-stack"><div></div><div></div><div><i class="sa-play"></i><i class="sa-playback"></i></div></div>',
  },
  progress: {
    label: 'One activity has a beginning, a last move and a place to stop.',
    picture: '<div class="sa-path"><span><i class="sa-dot"></i></span><i></i><span><b class="sa-diamond"></b></span><i></i><span><b class="sa-check"></b></span></div>',
  },
  report: {
    label: 'Example parent view showing a completed shape matching activity and an earned Star.',
    picture: '<div class="sa-slip"><div class="sa-slip-head"><i></i><strong>Example session</strong></div><div><span class="sa-slip-icon"><i class="sa-diamond"></i></span><span>Shape matching</span><i class="sa-mini-check"></i></div><div><span class="sa-slip-icon"><i class="sa-star"></i></span><span>Star earned</span><i class="sa-mini-check"></i></div></div>',
  },
  done: {
    label: 'Brainy celebrates the end of the session.',
    picture: sky + twinkles + '<i class="sa-confetti"></i>' + mascot + '<i class="sa-done-seal"><i class="sa-check"></i></i>',
  },
};

export function art(scene) {
  if (!Object.hasOwn(scenes, scene)) return '';
  const {label, picture} = scenes[scene];
  return '<figure class="story-art sa-' + scene + '" role="img" aria-label="' + label + '"><div class="sa-picture" aria-hidden="true">' + picture + '</div></figure>';
}
