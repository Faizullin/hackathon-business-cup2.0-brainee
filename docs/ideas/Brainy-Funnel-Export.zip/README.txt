Brainy • 25-screen parent onboarding

Open locally
Extract this ZIP, then double-click Open Brainy.html. All fonts, artwork, styles and onboarding logic are embedded. No installation or internet connection is required.

Publish or edit
The website/ directory contains the editable site, including index.html, CSS, JavaScript modules and licensed fonts. Upload the contents of website/ to a static web host with index.html at the site root. Choose website/ as the output directory if your host asks. No build command or package installation is needed.
To preview the editable files locally, run python3 -m http.server 8000 --directory website from the extracted directory, then visit http://localhost:8000.

Browser answers stay on the device. Add ?tour=1 to a hosted link to open a fresh review without changing the saved family plan.

Membership
The offer screen contains monthly and annual choices. Live billing needs approved US prices, renewal terms and HTTPS checkout links. To configure plans, set window.BRAINY_OFFER.plans before the entry module loads in website/index.html. For each option supply label, price, terms and checkoutUrl. The checkout provider handles payments.
