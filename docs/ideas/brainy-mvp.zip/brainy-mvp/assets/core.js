/* Брейни MVP — ядро прототипа.
 * Здесь: хранилище (заменяется реальным API), сессии и гарды роутов, каталоги,
 * экономика, рендер Брейни, общие UI-утилиты.
 * Каждая функция Api.* помечена эндпоинтом из ROUTES.md, который она имитирует.
 */
(function(){
'use strict';
const ROOT=document.body.dataset.root||'';
const go=p=>{location.href=ROOT+p};
const $=id=>document.getElementById(id);

/* ================= STORAGE (mock backend) ================= */
const KEY_DB='brainy.db.v1', KEY_AUTH='brainy.auth.v1';
function readStore(k){
  try{const v=localStorage.getItem(k);if(v)return JSON.parse(v)}catch(e){}
  try{const w=JSON.parse(window.name||'{}');return w[k]||null}catch(e){return null}
}
function writeStore(k,v){
  let ok=false;
  try{localStorage.setItem(k,JSON.stringify(v));ok=true}catch(e){}
  if(!ok){try{const w=JSON.parse(window.name||'{}');w[k]=v;window.name=JSON.stringify(w)}catch(e){}}
}
const DAY=864e5;
const todayKey=(d=new Date())=>d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');
function weekStart(d=new Date()){const x=new Date(d);const wd=(x.getDay()+6)%7;x.setHours(0,0,0,0);x.setDate(x.getDate()-wd);return todayKey(x)}

function seed(){
  const t=todayKey();
  return {
    v:1,
    parent:{name:'Айгерим',email:'mama@example.com',pass:'demo1234',pin:'1234',consent:true},
    child:{id:'c1',name:'Амир',birthYear:2020,age:6,league:'6 лет'},
    onboarding:'done',            // signup → child → quiz → setup → done
    stats:{brain:66,eyes:41,mouth:55,arms:70,legs:64,resp:80},
    start:{brain:18,eyes:16,mouth:14,arms:14,legs:18,resp:10},
    skills:{speech:62,reading:48,logic:78,attention:41,memory:55,motor:70},
    skillsPrev:{speech:50,reading:40,logic:60,attention:30,memory:52,motor:58},
    traits:{long:58,ml:72,hard:35,mistakes:64,resp:80},
    traitsPrev:{long:50,ml:60,hard:25,mistakes:52,resp:66},
    mood:72,lastActive:t,
    wallet:{stars:340,suns:6,weekSuns:6,weekStart:weekStart()},
    goal:{target:10,prizeId:'g1'},
    acc:{head:null,face:'glasses',neck:null},owned:['glasses'],
    day:{date:t,inRow:0,bonusGiven:false,gamesPlayed:0},
    entryStats:{rec:19,skip:8,recFinished:23,recStarted:26},
    shop:{snake:{type:'forever'},rocket:{type:'timer',leftSec:360}},
    media:{},
    videos:{ocean:{pos:9,done:false}},
    promise:3,
    tasks:[
      {id:'t1',title:'15 минут логических игр',kind:'app',reward:15,skill:'Логика',status:'done',date:t,src:'manual'},
      {id:'t2',title:'Убраться в комнате',kind:'real',reward:2,skill:'Ответственность',status:'check',date:t,src:'template'},
      {id:'t3',title:'Прочитать книжку перед сном',kind:'real',reward:3,skill:'Чтение',status:'todo',date:t,src:'template'},
      {id:'t4',title:'Поиграть на улице 30 минут',kind:'real',reward:1,skill:'Моторика',status:'todo',date:t,src:'template'}
    ],
    recsUsed:[],
    gifts:[{id:'g1',title:'Поход в кино',price:10},{id:'g2',title:'Мороженое',price:3},{id:'g3',title:'Набор наклеек',price:2},{id:'g4',title:'Выбрать мультик на вечер',price:4},{id:'g5',title:'Парк аттракционов',price:15}],
    reqs:[{id:'r1',giftId:'g3',title:'Набор наклеек',at:Date.now()-DAY,status:'pending'}],
    feed:[
      {at:Date.now()-2*36e5,text:'Амир отметил «Убраться в комнате» — ждёт подтверждения',kind:'task'},
      {at:Date.now()-3*36e5,text:'Прошёл «Продолжи узор», уровень 2 · +14 ★',kind:'game'},
      {at:Date.now()-DAY,text:'Купил подарок «Набор наклеек» за 2 ☀',kind:'gift'}
    ],
    pairCode:'482915',
    devices:[{id:'d1',name:'iPad Амира',paired:Date.now()-50*DAY}],
    events:[]
  };
}

let DB=readStore(KEY_DB);
if(!DB||DB.v!==1)DB=seed();
let AUTH=readStore(KEY_AUTH)||{parent:false,childDevice:null,elevatedUntil:0,entryDone:false};

/* daily / weekly rollovers (на сервере — по крону и при первом запросе дня) */
(function rollover(){
  const t=todayKey();
  if(DB.day.date!==t){
    const days=Math.max(1,Math.round((new Date(t)-new Date(DB.lastActive))/DAY));
    DB.mood=Math.max(30,DB.mood-5*days);        // самочувствие медленно падает, нижний предел 30
    DB.day={date:t,inRow:0,bonusGiven:false,gamesPlayed:0};
    DB.tasks=DB.tasks.filter(x=>x.status!=='done'||x.date===t);
  }
  const ws=weekStart();
  if(DB.wallet.weekStart!==ws){DB.wallet.weekStart=ws;DB.wallet.weekSuns=0}
})();
function save(){writeStore(KEY_DB,DB);writeStore(KEY_AUTH,AUTH)}
save();

function track(name,props){DB.events.push({name,props:props||{},at:Date.now()});if(DB.events.length>300)DB.events.shift()}
function feed(text,kind){DB.feed.unshift({at:Date.now(),text,kind});DB.feed=DB.feed.slice(0,30)}

/* ================= CATALOGS ================= */
const SKILLS=[ // 6 умений: что проверяют при поступлении
  {k:'speech',n:'Речь',avg:55,part:'mouth'},{k:'reading',n:'Чтение',avg:55,part:'mouth'},
  {k:'logic',n:'Логика',avg:58,part:'brain'},{k:'attention',n:'Внимание',avg:52,part:'eyes'},
  {k:'memory',n:'Память',avg:56,part:'brain'},{k:'motor',n:'Моторика',avg:60,part:'arms'}
];
const TRAITS=[
  {k:'long',n:'Долгая игра'},{k:'ml',n:'Машина обучения'},{k:'hard',n:'Делай сложное'},{k:'mistakes',n:'Учусь на ошибках'},{k:'resp',n:'Ответственность'}
];
const DEV=[ // развивающие игры: зарабатывают звёзды
  {id:'odd',n:'Найди лишний',skill:'attention',sk:'Внимание',ic:'eye',t:'sky',r:'до 14',playable:true},
  {id:'pattern',n:'Продолжи узор',skill:'logic',sk:'Логика',ic:'pattern',t:'coral',r:'до 16',playable:true},
  {id:'sounds',n:'Звуки и буквы',skill:'reading',sk:'Чтение',ic:'letters',t:'sun',r:'до 14'},
  {id:'repeat',n:'Повтори за Брейни',skill:'memory',sk:'Память',ic:'memory',t:'mint',r:'до 12'},
  {id:'story',n:'Расскажи историю',skill:'speech',sk:'Речь',ic:'speech',t:'coral',r:'до 15'},
  {id:'garden',n:'Волшебный сад',skill:null,sk:'Долгая игра',ic:'sprout',t:'mint',r:'до 10 в день'},
  {id:'expedition',n:'Экспедиция',skill:null,sk:'Машина обучения',ic:'compass',t:'sky',r:'до 18'},
  {id:'detective',n:'Детектив ошибок',skill:null,sk:'Учусь на ошибках',ic:'detective',t:'sun',r:'до 14'}
];
const SHOP=[ // развлекательные игры: тратят звёзды
  {id:'snake',n:'Змейка',sk:'Пространственное мышление',ic:'snake',t:'mint',pt:30,pf:450,stat:'arms'},
  {id:'rocket',n:'Ракета-раннер',sk:'Скорость реакции',ic:'rocket',t:'coral',pt:30,pf:500,stat:'legs'},
  {id:'drums',n:'Ритм-барабаны',sk:'Чувство ритма',ic:'drum',t:'sun',pt:30,pf:450,stat:'arms'},
  {id:'catapult',n:'Катапульта',sk:'Меткость',ic:'target',t:'sky',pt:30,pf:500,stat:'arms'},
  {id:'maze',n:'Лабиринт-гонки',sk:'Ловкость рук',ic:'maze',t:'coral',pt:40,pf:600,stat:'arms'}
];
const VIDEOS=[
  {id:'volcano',kind:'cartoon',n:'Как устроен вулкан',d:22,ic:'play',t:'coral',price:50,bg:'linear-gradient(135deg,#5A1E12,#C2541F)',label:'Мультфильм'},
  {id:'drop',kind:'cartoon',n:'Путешествие капельки',d:18,ic:'play',t:'sky',price:40,bg:'linear-gradient(135deg,#0E3A66,#3C68EE)',label:'Мультфильм'},
  {id:'hedgehog',kind:'cartoon',n:'Сказка о смелом ёжике',d:15,ic:'phones',t:'sun',price:30,bg:'linear-gradient(135deg,#4A3A0B,#B98A14)',label:'Аудиосказка'},
  {id:'ocean',kind:'popsci',n:'Тайны океана',d:24,ic:'wave',t:'sky',price:0,bg:'linear-gradient(135deg,#0E3A66,#1A86A8)',q:'Кто самый большой житель океана?',o:['Синий кит','Акула','Осьминог'],a:0},
  {id:'bees',kind:'popsci',n:'Как живут пчёлы',d:20,ic:'bee',t:'sun',price:0,bg:'linear-gradient(135deg,#6B4A0B,#C98A14)',q:'Что пчёлы делают из нектара?',o:['Воск','Мёд','Сахар'],a:1},
  {id:'mars',kind:'popsci',n:'Путешествие к Марсу',d:26,ic:'planet',t:'coral',price:0,bg:'linear-gradient(135deg,#3B1416,#A8402E)',q:'Какого цвета Марс?',o:['Синего','Зелёного','Красного'],a:2},
  {id:'dino',kind:'popsci',n:'Последние дни динозавров',d:22,ic:'dino',t:'mint',price:0,bg:'linear-gradient(135deg,#123B2C,#2E7D5B)',q:'Что, по главной версии учёных, упало на Землю?',o:['Астероид','Луна','Ледяная гора'],a:0}
];
const ACC=[
  {id:'cowboy',n:'Ковбойская шляпа',slot:'head',p:120},{id:'cap',n:'Кепка',slot:'head',p:60},{id:'phones',n:'Наушники',slot:'head',p:90},
  {id:'glasses',n:'Очки',slot:'face',p:80},{id:'bowtie',n:'Бабочка',slot:'neck',p:50},{id:'scarf',n:'Шарф',slot:'neck',p:70}
];
const PARTS=[['brain','Мозг','Логика, память'],['eyes','Глаза','Внимание и концентрация'],['mouth','Рот','Речь и чтение'],['arms','Руки','Моторика, ловкость'],['legs','Ноги','Реакция, координация']];
const TASK_SKILLS=['Ответственность','Внимание','Чтение','Речь','Память','Логика','Моторика','Делай сложное'];
const TEMPLATES=[
  {label:'Убраться',title:'Убраться в комнате',skill:'Ответственность',reward:2},
  {label:'Улица',title:'Поиграть на улице 30 минут',skill:'Моторика',reward:1},
  {label:'Книжка',title:'Прочитать книжку',skill:'Чтение',reward:3},
  {label:'Домашка сам',title:'Сделать домашку самостоятельно',skill:'Ответственность',reward:2},
  {label:'Пятёрка',title:'Получить пятёрку в школе',skill:'Делай сложное',reward:3}
];
const RECS=[
  {id:'rc1',sk:'Внимание',skill:'attention',part:'Глаза Брейни',why:'Чаще всего бросает задания на внимание через 4–5 минут.',title:'Собрать пазл из 60 деталей вместе с вами',reward:3,dur:'20 мин'},
  {id:'rc2',sk:'Внимание',skill:'attention',part:'Глаза Брейни',why:'Чаще всего бросает задания на внимание через 4–5 минут.',title:'Игра «Замри» на прогулке',reward:1,dur:'10 мин'},
  {id:'rc3',sk:'Делай сложное',trait:'hard',avg:47,part:'Плащ героя',why:'На входе выбирает «другие игры» в 30% случаев.',title:'Слепить из пластилина фигурку, которую ещё не пробовал',reward:2,dur:'25 мин'},
  {id:'rc4',sk:'Чтение',skill:'reading',part:'Рот Брейни',why:'Растёт медленнее среднего: +8 за месяц при +12 у сверстников.',title:'Прочитать 5 вывесок по дороге домой',reward:1,dur:'10 мин'}
];

/* ================= RULES / ECONOMY ================= */
const RULES={
  starFirstTry:3, starAfterFix:4, popsciReward:15, streakBonus:5, streakLen:3,
  sunToStars:10, tasksPerDay:5, moodPerGame:8, popsciEyes:2, taskResp:2,
  timerMinutes:10, elevatedMin:15
};
const STAGES=[['Сонный',0],['Проснувшийся',25],['Бодрый',40],['Умник',55],['Гений',70]];
const avg5=s=>(s.brain+s.eyes+s.mouth+s.arms+s.legs)/5, avg=avg5;
function stageInfo(s){const m=avg5(s);let i=0;STAGES.forEach((x,k)=>{if(m>=x[1])i=k});
  const next=STAGES[i+1];return {i,name:STAGES[i][0],m,next:next?next[0]:null,left:next?Math.ceil(next[1]-m):0,
  prog:next?(m-STAGES[i][1])/(next[1]-STAGES[i][1]):1}}
function stagesHTML(s){const st=stageInfo(s);return STAGES.map((x,k)=>'<div class="'+(k===st.i?'on':'')+'"><i><b style="width:'+(k<st.i?100:k===st.i?Math.round(st.prog*100):0)+'%"></b></i>'+x[0]+'</div>').join('')}
const clampN=(v,a=0,b=100)=>Math.max(a,Math.min(b,v));

/* Алгоритм входного экрана: 3 навыка с наибольшим отставанием от среднего по возрасту,
   для каждого — игра этого навыка (в MVP: реже всего игранная за 7 дней). */
function recommendations(){
  return SKILLS.filter(s=>DEV.some(g=>g.skill===s.k))
    .map(s=>({...s,v:Math.round(DB.skills[s.k]),lag:DB.skills[s.k]-s.avg,game:DEV.find(g=>g.skill===s.k)}))
    .sort((a,b)=>a.lag-b.lag).slice(0,3);
}

/* ================= API (mock) ================= */
const today=()=>todayKey();
const Api={
  // GET /api/me
  me:()=>DB,
  // POST /api/child/entry  {choice:'recommendation'|'skip', gameId, rank}
  entryChoice(choice,gameId,rank){
    if(choice==='skip'){DB.entryStats.skip++;track('entry_skipped')}
    else{DB.entryStats.rec++;DB.entryStats.recStarted++;track('entry_recommendation_chosen',{game_id:gameId,rank})}
    AUTH.entryDone=true;save();
  },
  // POST /api/child/games/:id/finish  {level, rounds, mistakes, corrections, stars}
  finishGame(id,level,res){
    const before=JSON.parse(JSON.stringify(DB.stats)),stBefore=stageInfo(DB.stats).i;
    const G=GAMES[id];
    for(const k in G.gain)DB.stats[k]=clampN(DB.stats[k]+G.gain[k]);
    for(const k in G.skillGain)DB.skills[k]=clampN(DB.skills[k]+G.skillGain[k]);
    if(res.corrections>0)DB.traits.mistakes=clampN(DB.traits.mistakes+1);
    let stars=res.stars,bonus=0;
    DB.day.inRow++;DB.day.gamesPlayed++;
    if(DB.day.inRow>=RULES.streakLen&&!DB.day.bonusGiven){DB.day.bonusGiven=true;bonus=RULES.streakBonus;track('break_suggested')}
    DB.wallet.stars+=stars+bonus;
    DB.mood=clampN(DB.mood+RULES.moodPerGame);DB.lastActive=today();
    // задания «в приложении» засчитываются сами
    DB.tasks.filter(t=>t.kind==='app'&&t.status==='todo'&&t.date===today()).forEach(t=>{t.status='done';DB.wallet.stars+=t.reward;feed('Задание «'+t.title+'» выполнено в приложении · +'+t.reward+' ★','task')});
    const stAfter=stageInfo(DB.stats).i;
    feed('Прошёл «'+G.n+'», уровень '+level+' · +'+(stars+bonus)+' ★','game');
    if(stAfter>stBefore){feed('Брейни перешёл на стадию «'+STAGES[stAfter][0]+'»! (push)','stage');track('stage_up',{from:STAGES[stBefore][0],to:STAGES[stAfter][0]})}
    track('game_finished',{game_id:id,level,...res});
    save();
    return {before,after:DB.stats,bonus,inRow:DB.day.inRow,stageUp:stAfter>stBefore?STAGES[stAfter][0]:null};
  },
  // POST /api/child/session/stop
  stopForToday(){DB.day.inRow=0;track('next_step_chosen',{choice:'stop'});save()},
  // POST /api/child/shop/:id/unlock {type:'timer'|'forever'}
  unlock(id,type){
    const g=SHOP.find(x=>x.id===id),cost=type==='timer'?g.pt:g.pf;
    if(DB.wallet.stars<cost)return {ok:false,need:cost-DB.wallet.stars};
    DB.wallet.stars-=cost;
    const cur=DB.shop[id];
    DB.shop[id]=type==='forever'?{type:'forever'}:{type:'timer',leftSec:(cur&&cur.type==='timer'?cur.leftSec:0)+RULES.timerMinutes*60};
    track('shop_unlock',{item:id,type,cost});save();return {ok:true,cost};
  },
  // POST /api/child/shop/:id/heartbeat {sec}  — списывает игровое время
  spendTimer(id,sec){const s=DB.shop[id];if(s&&s.type==='timer'){s.leftSec=Math.max(0,s.leftSec-sec);if(!s.leftSec)delete DB.shop[id]}save();return DB.shop[id]},
  // POST /api/child/shop/:id/finish {minutes}
  funPlayed(id,min){const g=SHOP.find(x=>x.id===id);track('fun_finished',{item:id,seconds:Math.round(min*60)});if(min>=1)DB.stats[g.stat]=clampN(DB.stats[g.stat]+1);DB.lastActive=today();save()},
  // POST /api/child/videos/:id/unlock
  unlockVideo(id){const v=VIDEOS.find(x=>x.id===id);if(DB.wallet.stars<v.price)return {ok:false,need:v.price-DB.wallet.stars};
    DB.wallet.stars-=v.price;DB.media[id]=true;track('shop_unlock',{item:id,type:'video',cost:v.price});save();return {ok:true}},
  // PUT /api/child/videos/:id/progress {position}
  videoPos(id,pos){DB.videos[id]=DB.videos[id]||{pos:0,done:false};DB.videos[id].pos=pos;save()},
  // POST /api/child/videos/:id/answer {option}
  videoAnswer(id,opt){
    const v=VIDEOS.find(x=>x.id===id),ok=opt===v.a;
    track('video_question_answered',{video_id:id,correct:ok});
    if(ok&&!DB.videos[id].done){DB.videos[id].done=true;DB.wallet.stars+=RULES.popsciReward;DB.stats.eyes=clampN(DB.stats.eyes+RULES.popsciEyes);DB.skills.attention=clampN(DB.skills.attention+1);feed('Досмотрел научпоп «'+v.n+'» и ответил верно · +15 ★','video')}
    save();return ok;
  },
  // POST /api/child/accessories/:id/buy  |  PUT /api/child/accessories/:id/equip
  accessory(id){
    const a=ACC.find(x=>x.id===id);
    if(!DB.owned.includes(id)){
      if(DB.wallet.stars<a.p)return {ok:false,need:a.p-DB.wallet.stars};
      DB.wallet.stars-=a.p;DB.owned.push(id);DB.acc[a.slot]=id;track('accessory_bought',{id});save();return {ok:true,bought:true,a};
    }
    DB.acc[a.slot]=DB.acc[a.slot]===id?null:id;track('accessory_equipped',{id,on:!!DB.acc[a.slot]});save();return {ok:true,a,on:!!DB.acc[a.slot]};
  },
  // POST /api/child/tasks/:id/done
  childDone(tid){const t=DB.tasks.find(x=>x.id===tid);if(!t||t.status!=='todo'||t.kind!=='real')return;t.status='check';
    feed(DB.child.name+' отметил «'+t.title+'» — ждёт подтверждения','task');track('task_marked_done_by_child',{task_id:tid});save()},
  // POST /api/child/gifts/:id/buy
  buyGift(gid){const g=DB.gifts.find(x=>x.id===gid);if(!g||DB.wallet.suns<g.price)return false;
    DB.wallet.suns-=g.price;DB.reqs.unshift({id:'r'+Date.now(),giftId:gid,title:g.title,at:Date.now(),status:'pending'});
    feed('Купил подарок «'+g.title+'» за '+g.price+' ☀ — нужно вручить','gift');track('gift_bought',{gift_id:gid});save();return true},
  // POST /api/child/wallet/exchange {suns:1}
  exchange(){if(DB.wallet.suns<1)return false;DB.wallet.suns--;DB.wallet.stars+=RULES.sunToStars;track('suns_exchanged',{suns:1});save();return true},

  /* ---- parent ---- */
  todayTasks:()=>DB.tasks.filter(t=>t.date===today()),
  // POST /api/parent/tasks
  createTask(t){
    if(Api.todayTasks().length>=RULES.tasksPerDay)return {ok:false,reason:'limit'};
    const task={id:'t'+Date.now(),status:'todo',date:today(),...t};DB.tasks.push(task);
    track('task_created',{source:t.src});save();return {ok:true,task};
  },
  // POST /api/parent/tasks/:id/confirm
  confirmTask(tid){
    const t=DB.tasks.find(x=>x.id===tid);if(!t||t.status!=='check')return null;
    t.status='done';let goalReached=false;
    if(t.kind==='real'){
      const was=DB.wallet.weekSuns;DB.wallet.suns+=t.reward;DB.wallet.weekSuns+=t.reward;
      DB.stats.resp=clampN(DB.stats.resp+RULES.taskResp);DB.traits.resp=clampN(DB.traits.resp+1);
      if(was<DB.goal.target&&DB.wallet.weekSuns>=DB.goal.target){goalReached=true;track('weekly_goal_reached')}
    }else DB.wallet.stars+=t.reward;
    track('task_confirmed',{task_id:tid});save();return {t,goalReached};
  },
  // DELETE /api/parent/tasks/:id
  deleteTask(tid){DB.tasks=DB.tasks.filter(x=>x.id!==tid);save()},
  // PUT /api/parent/goal
  setGoal(target,prizeId){DB.goal={target,prizeId};save()},
  // POST /api/parent/gifts  |  DELETE /api/parent/gifts/:id
  addGift(title,price){DB.gifts.push({id:'g'+Date.now(),title,price});save()},
  removeGift(id){DB.gifts=DB.gifts.filter(g=>g.id!==id);if(DB.goal.prizeId===id&&DB.gifts[0])DB.goal.prizeId=DB.gifts[0].id;save()},
  // POST /api/parent/gift-requests/:id/deliver
  deliver(rid){const r=DB.reqs.find(x=>x.id===rid);if(r){r.status='delivered';track('gift_delivered',{request_id:rid});save()}},
  // PUT /api/parent/child
  updateChild(p){Object.assign(DB.child,p);save()},
  // PUT /api/parent/pin
  setPin(pin){DB.parent.pin=pin;save()},
  // POST /api/parent/devices/pair-code
  newPairCode(){DB.pairCode=String(Math.floor(100000+Math.random()*900000));save();return DB.pairCode},
  prize:()=>DB.gifts.find(g=>g.id===DB.goal.prizeId)||DB.gifts[0]||{title:'—',id:null},
  pending:()=>({tasks:DB.tasks.filter(t=>t.status==='check').length,gifts:DB.reqs.filter(r=>r.status==='pending').length}),
  save,track,feed
};

/* ================= AUTH & GUARDS ================= */
const PARENT_PAGES={home:'parent/index.html',tasks:'parent/tasks.html',rewards:'parent/rewards.html',settings:'parent/settings.html'};
const Auth={
  get:()=>AUTH,
  // POST /api/auth/login
  login(email,pass){if(!DB.parent||DB.parent.email.toLowerCase()!==email.trim().toLowerCase()||DB.parent.pass!==pass)return false;AUTH.parent=true;save();return true},
  // POST /api/auth/signup
  signup(p){DB=seed();DB.parent={...p,pin:null};DB.onboarding='child';DB.child={id:'c1',name:'',birthYear:2020,age:6,league:'6 лет'};
    Object.assign(DB,{tasks:[],reqs:[],feed:[],videos:{},shop:{},media:{},owned:[],acc:{head:null,face:null,neck:null},
      wallet:{stars:50,suns:0,weekSuns:0,weekStart:weekStart()},entryStats:{rec:0,skip:0,recFinished:0,recStarted:0},fresh:true,devices:[],mood:60});
    AUTH={parent:true,childDevice:null,elevatedUntil:0,entryDone:false};save()},
  logout(){AUTH.parent=false;AUTH.elevatedUntil=0;save();go('index.html')},
  // POST /api/child-device/pair {code}  → device token со scope=child
  pair(code){if(code!==DB.pairCode)return false;AUTH.childDevice=DB.child.id;AUTH.entryDone=false;AUTH.elevatedUntil=0;save();return true},
  // Родитель отдаёт своё устройство ребёнку (общий планшет)
  toChildMode(){AUTH.childDevice=DB.child.id;AUTH.entryDone=false;AUTH.elevatedUntil=0;save();go('child/start.html')},
  unpair(){AUTH.childDevice=null;AUTH.entryDone=false;save()},
  // POST /api/parent/gate {pin} → elevated token на 15 минут
  gate(pin){if(pin!==DB.parent.pin)return false;AUTH.elevatedUntil=Date.now()+RULES.elevatedMin*60e3;AUTH.parent=true;save();return true},
  guard(role,page){
    if(role==='parent'){
      if(!DB.parent||!DB.parent.email){go('auth/signup.html');return false}
      if(AUTH.childDevice&&Date.now()>AUTH.elevatedUntil){go('parent/gate.html#'+(page||'home'));return false}
      if(!AUTH.parent){go('auth/login.html');return false}
      if(DB.onboarding!=='done'){go('onboarding/'+DB.onboarding+'.html');return false}
      return true;
    }
    if(role==='child'){
      if(!AUTH.childDevice){go('child/login.html');return false}
      if(!AUTH.entryDone&&page!=='start'){go('child/start.html');return false}
      return true;
    }
    return true;
  }
};

/* ================= UI ================= */
const ICONS={
  pattern:'<circle cx="11" cy="24" r="6"/><rect x="20" y="18" width="12" height="12" rx="2"/><path d="M40 17l6 13h-12z"/>',
  eye:'<circle cx="21" cy="21" r="11"/><path d="M29 29l10 10"/>',
  letters:'<path d="M6 37l8-25 8 25M9 29h10"/><path d="M28 22c2-3 11-3 11 3v12M39 30c-3-2-11-2-11 3s8 5 11 1"/>',
  memory:'<rect x="7" y="9" width="15" height="20" rx="3"/><rect x="26" y="19" width="15" height="20" rx="3"/><path d="M14 16v6M33 26v6"/>',
  speech:'<path d="M8 11h32v21H22l-8 7v-7H8z"/><path d="M16 21h16"/>',
  sprout:'<path d="M24 41V22"/><path d="M24 27c-10 0-14-6-14-13 8 0 14 4 14 13z"/><path d="M24 22c0-8 6-12 14-12 0 6-4 12-14 12z"/>',
  compass:'<circle cx="24" cy="24" r="16"/><path d="M31 17l-4 11-10 3 4-11z"/>',
  detective:'<path d="M9 12l10 10M19 12L9 22"/><path d="M22 32l6 6 13-15"/>',
  snake:'<path d="M7 35h14a6 6 0 0 0 0-12h-6a6 6 0 0 1 0-12h20"/><circle cx="39" cy="11" r="1.5"/>',
  rocket:'<path d="M24 5c8 6 10 17 6 27H18C14 22 16 11 24 5z"/><path d="M18 32l-6 8M30 32l6 8M24 34v8"/><circle cx="24" cy="18" r="3"/>',
  drum:'<ellipse cx="24" cy="19" rx="14" ry="5"/><path d="M10 19v13c0 3 6 5 14 5s14-2 14-5V19"/><path d="M13 6l9 10M35 6l-9 10"/>',
  target:'<circle cx="24" cy="24" r="16"/><circle cx="24" cy="24" r="8"/><circle cx="24" cy="24" r="1.5"/>',
  maze:'<rect x="7" y="7" width="34" height="34" rx="4"/><path d="M16 7v17h9M33 15v26M16 33h9"/>',
  play:'<circle cx="24" cy="24" r="16"/><path d="M20 16l12 8-12 8z"/>',
  phones:'<path d="M9 31v-7a15 15 0 0 1 30 0v7"/><rect x="7" y="29" width="8" height="12" rx="2"/><rect x="33" y="29" width="8" height="12" rx="2"/>',
  wave:'<path d="M4 30c5-6 10-6 15 0s10 6 15 0 10-6 15 0"/><path d="M4 38c5-6 10-6 15 0s10 6 15 0 10-6 15 0"/><circle cx="34" cy="14" r="5"/>',
  bee:'<ellipse cx="24" cy="28" rx="10" ry="13"/><path d="M14 24h20M14 31h20"/><path d="M18 16c-6-8-14-4-12 2M30 16c6-8 14-4 12 2"/>',
  planet:'<circle cx="24" cy="24" r="12"/><ellipse cx="24" cy="24" rx="21" ry="7" transform="rotate(-20 24 24)"/>',
  dino:'<path d="M8 38v-8c0-8 6-12 14-12h6l4-8 8 2-2 8h-4v6c0 6-4 12-10 12"/><path d="M14 38v4M26 38v4"/>',
  gift:'<rect x="7" y="18" width="34" height="23" rx="3"/><path d="M5 12h38v6H5zM24 12v29"/><path d="M24 12c-4-8-14-6-10 0M24 12c4-8 14-6 10 0"/>',
  tablet:'<rect x="5" y="3" width="14" height="18" rx="2"/><path d="M11 18h2"/>',
  home:'<path d="M4 11l8-7 8 7v9H4z"/><path d="M10 20v-5h4v5"/>'
};
Object.assign(ICONS,{
  learn:'<path d="M4 6.5C4 5 5 4 6.5 4H12v16H6.5C5 20 4 19 4 17.5z"/><path d="M20 6.5C20 5 19 4 17.5 4H12v16h5.5c1.5 0 2.5-1 2.5-2.5z"/>',
  leisure:'<rect x="2.5" y="7" width="19" height="11" rx="4"/><path d="M7 10.5v4M5 12.5h4"/><circle cx="16" cy="11.5" r="1"/><circle cx="18" cy="14" r="1"/>',
  giftT:'<rect x="3.5" y="9" width="17" height="11.5" rx="1.5"/><path d="M2.5 6h19v3h-19zM12 6v14.5"/><path d="M12 6c-2-4-7-3-5 0M12 6c2-4 7-3 5 0"/>',
  brainyT:'<circle cx="8.5" cy="9" r="4.5"/><circle cx="15.5" cy="9" r="4.5"/><ellipse cx="12" cy="13" rx="8" ry="6"/><circle cx="9.5" cy="13.5" r="1"/><circle cx="14.5" cy="13.5" r="1"/>',
  chart:'<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/>',
  list:'<path d="M9 6h11M9 12h11M9 18h11"/><path d="M4 6l1 1 2-2M4 12l1 1 2-2M4 18l1 1 2-2"/>',
  cog:'<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/>',
  lock:'<rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>',
  x:'<path d="M5 5l14 14M19 5L5 19"/>',
  back:'<path d="M15 5l-7 7 7 7"/>',
  kid:'<circle cx="12" cy="7" r="4"/><path d="M4 21c0-4 3.6-7 8-7s8 3 8 7"/>'
});
const icon=(k,vb)=>'<svg viewBox="'+(vb||'0 0 48 48')+'" aria-hidden="true">'+ICONS[k]+'</svg>';
const ico24=k=>icon(k,'0 0 24 24');
const STAR='<svg class="star" viewBox="0 0 24 24"><path d="M12 2.5l2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.4 6.1 20.5l1.2-6.5L2.5 9.4l6.6-.9z"/></svg>';
const SUN='<svg class="sunic" viewBox="0 0 24 24"><circle cx="12" cy="12" r="5" fill="currentColor"/><g stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M12 1.5v3M12 19.5v3M1.5 12h3M19.5 12h3M4.6 4.6l2.1 2.1M17.3 17.3l2.1 2.1M4.6 19.4l2.1-2.1M17.3 6.7l2.1-2.1"/></g></svg>';
const LOGO='<svg viewBox="0 0 40 40" aria-hidden="true"><circle cx="13" cy="15" r="9" fill="#FF8FA3"/><circle cx="27" cy="15" r="9" fill="#FF8FA3"/><ellipse cx="20" cy="22" rx="15" ry="12" fill="#FF8FA3"/><path d="M20 8v12M11 18q3-3 6 0M23 18q3-3 6 0" stroke="#E2607A" stroke-width="2" fill="none" stroke-linecap="round"/><circle cx="15" cy="24" r="3" fill="#fff"/><circle cx="25" cy="24" r="3" fill="#fff"/><circle cx="15.5" cy="24.5" r="1.4" fill="#2B2350"/><circle cx="25.5" cy="24.5" r="1.4" fill="#2B2350"/></svg>';

let toastEl,tt;
function toast(m){
  if(!toastEl){toastEl=document.createElement('div');toastEl.className='toast';toastEl.setAttribute('role','status');toastEl.setAttribute('aria-live','polite');document.body.appendChild(toastEl)}
  toastEl.textContent=m;toastEl.classList.add('on');clearTimeout(tt);tt=setTimeout(()=>toastEl.classList.remove('on'),2800);
}
function flash(m){try{sessionStorage.setItem('brainy.flash',m)}catch(e){}}
function popFlash(){try{const m=sessionStorage.getItem('brainy.flash');if(m){sessionStorage.removeItem('brainy.flash');setTimeout(()=>toast(m),200)}}catch(e){}}
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function ago(ts){const m=Math.round((Date.now()-ts)/6e4);if(m<1)return 'только что';if(m<60)return m+' мин назад';const h=Math.round(m/60);if(h<24)return h+' ч назад';const d=Math.round(h/24);return d===1?'вчера':d+' дн назад'}
function plural(n,a,b,c){n=Math.abs(n)%100;const n1=n%10;if(n>10&&n<20)return c;if(n1>1&&n1<5)return b;if(n1===1)return a;return c}

/* демо-панель: карта экранов и сброс (в продукте нет) */
function devbar(){
  const a=document.createElement('a');a.className='devbar';a.href=ROOT+'index.html#map';a.textContent='Демо · карта экранов';
  document.body.appendChild(a);
}

/* ================= BRAINY SVG ================= */
const clamp=v=>Math.max(0,Math.min(1,v));
function hex(h){return [1,3,5].map(i=>parseInt(h.slice(i,i+2),16))}
function mix(a,b,t){const A=hex(a),B=hex(b);return '#'+A.map((v,i)=>Math.round(v+(B[i]-v)*t).toString(16).padStart(2,'0')).join('')}
function brainy(s,id,acc){
  acc=acc||{};
  const cx=120,cy=124,rx=58+s.brain*.28,ry=rx*.8;
  const mood=avg(s)/100,t=clamp((mood-.22)/.5);
  const F=mix('#A7BC8C','#FF8FA3',t),D=mix('#7A9064','#E05C77',t),P='#2B2350';
  let o='';
  const ly=cy+ry*.74,len=22+s.legs*.3;
  [-1,1].forEach(d=>{const x=cx+d*rx*.32;o+='<path d="M'+x+' '+ly+' L'+(x+d*3)+' '+(ly+len)+'" stroke="'+D+'" stroke-width="'+(8+s.legs*.05)+'" stroke-linecap="round"/><ellipse cx="'+(x+d*8)+'" cy="'+(ly+len+4)+'" rx="14" ry="7" fill="'+P+'"/>'});
  const sy=cy+ry*.15,aw=6+s.arms*.14;
  [-1,1].forEach(d=>{
    const sx=cx+d*rx*.9,ex=cx+d*(rx+20),ey=sy+20,hx=cx+d*(rx+30),hy=sy+34-s.arms*.5;
    o+='<path d="M'+sx+' '+sy+' Q'+ex+' '+(ey+8)+' '+hx+' '+hy+'" stroke="'+D+'" stroke-width="'+aw+'" fill="none" stroke-linecap="round"/>';
    if(s.arms>55)o+='<circle cx="'+(ex-d*2)+'" cy="'+(ey-2)+'" r="'+((s.arms-40)*.2)+'" fill="'+D+'"/>';
    o+='<circle cx="'+hx+'" cy="'+hy+'" r="'+(7+s.arms*.03)+'" fill="'+F+'" stroke="'+D+'" stroke-width="3"/>';
  });
  if(s.resp>=70)o+='<rect x="'+(cx+rx*.55)+'" y="'+(cy-ry*.2)+'" width="'+(rx*.5)+'" height="'+(ry*.85)+'" rx="10" fill="#3C68EE"/><rect x="'+(cx+rx*.62)+'" y="'+(cy+ry*.15)+'" width="'+(rx*.34)+'" height="'+(ry*.25)+'" rx="5" fill="#7A97FF"/>';
  [[-.55,-.55,.52],[0,-.78,.52],[.55,-.55,.52],[-.86,0,.46],[.86,0,.46],[-.5,.45,.5],[.5,.45,.5]].forEach(b=>o+='<circle cx="'+(cx+b[0]*rx)+'" cy="'+(cy+b[1]*ry)+'" r="'+(b[2]*ry)+'" fill="'+F+'"/>');
  o+='<ellipse cx="'+cx+'" cy="'+cy+'" rx="'+rx+'" ry="'+ry+'" fill="'+F+'"/>';
  const fs='stroke="'+D+'" stroke-width="3" fill="none" stroke-linecap="round" opacity=".6"';
  o+='<path d="M'+cx+' '+(cy-ry*1.22)+' Q'+(cx-7)+' '+(cy-ry*.8)+' '+cx+' '+(cy-ry*.38)+'" '+fs+'/>';
  [-1,1].forEach(d=>{
    o+='<path d="M'+(cx+d*rx*.22)+' '+(cy-ry*.8)+' q'+(d*rx*.14)+' '+(-ry*.16)+' '+(d*rx*.28)+' 0 t'+(d*rx*.28)+' 0" '+fs+'/>';
    o+='<path d="M'+(cx+d*rx*.5)+' '+(cy-ry*.38)+' q'+(d*rx*.12)+' '+(-ry*.14)+' '+(d*rx*.24)+' 0" '+fs+'/>';
  });
  const ey=cy+ry*.08,er=13+s.brain*.03,lid=(1-s.eyes/100)*2*er*.82,eyes=[];
  [-1,1].forEach((d,i)=>{
    const ex=cx+d*rx*.36,cid=id+'e'+i;eyes.push(ex);
    o+='<clipPath id="'+cid+'"><circle cx="'+ex+'" cy="'+ey+'" r="'+er+'"/></clipPath>';
    o+='<g clip-path="url(#'+cid+')"><circle cx="'+ex+'" cy="'+ey+'" r="'+er+'" fill="#fff"/><circle cx="'+(ex+2)+'" cy="'+(ey+3)+'" r="'+(er*.45)+'" fill="'+P+'"/><circle cx="'+(ex+4)+'" cy="'+ey+'" r="'+(er*.14)+'" fill="#fff"/>';
    o+='<rect x="'+(ex-er)+'" y="'+(ey-er)+'" width="'+(er*2)+'" height="'+lid+'" fill="'+F+'"/></g>';
    if(lid>2)o+='<path d="M'+(ex-er*.9)+' '+(ey-er+lid)+' L'+(ex+er*.9)+' '+(ey-er+lid)+'" stroke="'+D+'" stroke-width="3" stroke-linecap="round"/>';
    if(s.eyes<45)o+='<path d="M'+(ex-er*.7)+' '+(ey+er+4)+' q'+(er*.7)+' 6 '+(er*1.4)+' 0" stroke="#6B5A88" stroke-width="2.5" fill="none" opacity=".5"/>';
    if(t>.6)o+='<ellipse cx="'+(ex+d*er*.4)+'" cy="'+(ey+er+12)+'" rx="8" ry="5" fill="#FF5E7E" opacity=".35"/>';
  });
  if(acc.face==='glasses'){
    const gr=er+5;o+='<g fill="rgba(190,225,255,.22)" stroke="'+P+'" stroke-width="4">'+eyes.map(x=>'<circle cx="'+x+'" cy="'+ey+'" r="'+gr+'"/>').join('')+'</g><path d="M'+(eyes[0]+gr)+' '+ey+' Q'+cx+' '+(ey-8)+' '+(eyes[1]-gr)+' '+ey+'" stroke="'+P+'" stroke-width="4" fill="none"/>';
  }
  const my=cy+ry*.55,mw=14+s.mouth*.1,cv=(s.mouth-45)*.38;
  o+='<path d="M'+(cx-mw)+' '+my+' Q'+cx+' '+(my+cv)+' '+(cx+mw)+' '+my+'" stroke="'+P+'" stroke-width="4" fill="none" stroke-linecap="round"/>';
  if(acc.neck==='bowtie'){const by=cy+ry*.93;o+='<path d="M'+cx+' '+by+' l-20 -11 v22z M'+cx+' '+by+' l20 -11 v22z" fill="#EE5A4A"/><circle cx="'+cx+'" cy="'+by+'" r="6" fill="#C2402F"/>'}
  if(acc.neck==='scarf'){const sy2=cy+ry*.78;o+='<rect x="'+(cx-rx*.72)+'" y="'+sy2+'" width="'+(rx*1.44)+'" height="15" rx="7" fill="#139E80"/><rect x="'+(cx+rx*.25)+'" y="'+(sy2+8)+'" width="14" height="34" rx="5" fill="#0F7F67"/><path d="M'+(cx-rx*.5)+' '+(sy2+2)+'v11M'+(cx-rx*.2)+' '+(sy2+2)+'v11M'+(cx+rx*.1)+' '+(sy2+2)+'v11" stroke="#FFC845" stroke-width="3"/>'}
  if(acc.head==='cowboy'){
    o+='<path d="M'+(cx-rx*.48)+' '+(cy-ry*1.1)+' C'+(cx-rx*.52)+' '+(cy-ry*1.78)+' '+(cx-rx*.15)+' '+(cy-ry*1.62)+' '+cx+' '+(cy-ry*1.5)+' C'+(cx+rx*.15)+' '+(cy-ry*1.62)+' '+(cx+rx*.52)+' '+(cy-ry*1.78)+' '+(cx+rx*.48)+' '+(cy-ry*1.1)+'Z" fill="#B5763D"/>';
    o+='<rect x="'+(cx-rx*.48)+'" y="'+(cy-ry*1.24)+'" width="'+(rx*.96)+'" height="'+(ry*.12)+'" fill="#5A3418"/>';
    o+='<path d="M'+(cx-rx*1.08)+' '+(cy-ry*1.22)+' Q'+cx+' '+(cy-ry*.82)+' '+(cx+rx*1.08)+' '+(cy-ry*1.22)+' Q'+cx+' '+(cy-ry*1.0)+' '+(cx-rx*1.08)+' '+(cy-ry*1.22)+'Z" fill="#9A6233"/>';
  }
  if(acc.head==='cap'){
    o+='<path d="M'+(cx-rx*.66)+' '+(cy-ry*1.0)+' Q'+cx+' '+(cy-ry*1.8)+' '+(cx+rx*.66)+' '+(cy-ry*1.0)+'Z" fill="#3C68EE"/><ellipse cx="'+(cx+rx*.6)+'" cy="'+(cy-ry*1.0)+'" rx="'+(rx*.42)+'" ry="'+(ry*.09)+'" fill="#2A4FC4"/><circle cx="'+cx+'" cy="'+(cy-ry*1.4)+'" r="5" fill="#2A4FC4"/>';
  }
  if(acc.head==='phones'){
    o+='<path d="M'+(cx-rx*.98)+' '+(cy-ry*.1)+' Q'+cx+' '+(cy-ry*2.05)+' '+(cx+rx*.98)+' '+(cy-ry*.1)+'" stroke="'+P+'" stroke-width="8" fill="none" stroke-linecap="round"/>';
    [-1,1].forEach(d=>o+='<rect x="'+(cx+d*rx*.98-11)+'" y="'+(cy-ry*.3)+'" width="22" height="34" rx="9" fill="#EE5A4A"/>');
  }
  if(mood<.38)[[-1,-.9,-18],[1,-1.05,14],[1.05,.3,-10]].forEach(p=>{const x=cx+p[0]*(rx+18),y=cy+p[1]*ry;o+='<g transform="rotate('+p[2]+' '+x+' '+y+')" opacity=".8"><rect x="'+(x-9)+'" y="'+(y-15)+'" width="18" height="30" rx="4" fill="#fff" stroke="'+D+'" stroke-width="2"/><path d="M'+(x-3)+' '+(y-5)+' l7 5 -7 5z" fill="'+D+'"/></g>'});
  if(s.eyes<35)o+='<text x="'+(cx+rx*.7)+'" y="'+(cy-ry*1.1)+'" font-family="Unbounded,Arial" font-weight="700" font-size="18" fill="#6B5A88">z z</text>';
  if(s.brain>72&&!acc.head)o+='<path d="M'+(cx-rx*1.05)+' '+(cy-ry*1.05)+' l4 9 9 4 -9 4 -4 9 -4-9 -9-4 9-4z" fill="#FFC845"/>';
  return '<svg class="brainy" viewBox="-12 -22 264 300" role="img" aria-label="Брейни">'+o+'</svg>';
}

window.B={ROOT,go,$,DB:()=>DB,AUTH:()=>AUTH,Api,Auth,RULES,STAGES,stageInfo,stagesHTML,avg5,recommendations,
  SKILLS,TRAITS,DEV,SHOP,VIDEOS,ACC,PARTS,TASK_SKILLS,TEMPLATES,RECS,
  icon,ico24,ICONS,STAR,SUN,LOGO,toast,flash,popFlash,esc,ago,plural,brainy,devbar,todayKey,
  reset(){DB=seed();AUTH={parent:false,childDevice:null,elevatedUntil:0,entryDone:false};save()}
};
/* Играбельные игры прототипа: уровни и раунды */
const GAMES=window.GAMES={
  pattern:{n:'Продолжи узор',chips:['coral|Логика · основной','sky|Внимание · доп.'],ic:'pattern',t:'coral',gain:{brain:2},skillGain:{logic:3,attention:1},gainT:'Мозг +2',type:'seq',
    L:{1:[
      {seq:[['circle','coral'],['square','sky'],['circle','coral'],['square','sky']],opts:[['circle','coral'],['square','sky'],['tri','sun']],ans:0},
      {seq:[['tri','mint'],['tri','mint'],['circle','coral'],['tri','mint'],['tri','mint']],opts:[['tri','mint'],['circle','coral'],['square','sky']],ans:1},
      {seq:[['circle','sky',.5],['circle','sky',.75],['circle','sky',1],['circle','sky',.5],['circle','sky',.75]],opts:[['circle','sky',.5],['circle','sky',1],['circle','sky',.75]],ans:1},
      {seq:[['square','coral'],['square','sun'],['square','mint'],['square','coral'],['square','sun']],opts:[['square','coral'],['square','sky'],['square','mint']],ans:2}],
     2:[
      {seq:[['circle','coral'],['circle','coral'],['square','sky'],['circle','coral'],['circle','coral'],['square','sky'],['circle','coral']],opts:[['square','sky'],['circle','coral'],['tri','sun']],ans:1},
      {seq:[['tri','mint',.5],['tri','mint',.75],['tri','mint',1],['square','sun',.5],['square','sun',.75]],opts:[['tri','mint',1],['square','sun',.5],['square','sun',1]],ans:2},
      {seq:[['circle','coral'],['circle','sky'],['circle','sky'],['circle','coral'],['circle','sky'],['circle','sky'],['circle','coral']],opts:[['circle','coral'],['circle','sky'],['square','sky']],ans:1},
      {seq:[['square','coral'],['tri','coral'],['circle','coral'],['square','sky'],['tri','sky']],opts:[['circle','coral'],['square','sky'],['circle','sky']],ans:2}]}},
  odd:{n:'Найди лишний',chips:['sky|Внимание · основной'],ic:'eye',t:'sky',gain:{eyes:3},skillGain:{attention:3},gainT:'Глаза +3',type:'odd',
    L:{1:[[['circle','sky'],['circle','coral'],4,9],[['square','mint'],['tri','mint'],7,9],[['tri','sun'],['tri','sky'],1,9],[['circle','coral'],['square','coral'],6,9]],
       2:[[['circle','sky',1],['circle','sky',.78],9,12],[['square','coral',1],['square','coral',.8],2,12],[['circle','mint'],['circle','sky'],5,12],[['tri','sun',1],['tri','sun',.78],11,12]]}}
};
B.GAMES=GAMES;
})();
