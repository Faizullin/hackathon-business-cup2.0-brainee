/* Брейни MVP — оболочки интерфейсов: ребёнок (док + нижние вкладки) и родитель (шапка + вкладки/сайдбар). */
(function(){
const {ROOT,DB,Api,Auth,ico24,STAR,SUN,LOGO,brainy,stageInfo,esc}=B;

/* ---------------- CHILD ---------------- */
const CHILD_TABS=[
  ['learn','Учимся','learn','child/learn.html'],
  ['leisure','Отдых','leisure','child/leisure.html'],
  ['gifts','Подарки','giftT','child/gifts.html'],
  ['brainy','Брейни','brainyT','child/brainy.html']
];
function dockHTML(){
  const d=DB(),st=stageInfo(d.stats),w=d.wallet,g=d.goal,prize=Api.prize();
  return '<div class="dock" id="dock">'+
    '<a class="dock-brainy" href="'+ROOT+'child/brainy.html" aria-label="Открыть Брейни">'+brainy(d.stats,'dock',d.acc)+'</a>'+
    '<div class="dock-info"><div class="row" style="gap:8px"><span class="dname">Брейни</span><span class="chip coral">'+st.name+'</span></div>'+
      '<div class="mood"><span class="small muted">Самочувствие</span><div class="bar"><span style="width:'+d.mood+'%"></span></div><span class="small num">'+d.mood+'%</span></div>'+
      '<span class="small muted">'+(st.next?'До стадии «'+st.next+'» осталось '+st.left+' очк.':'Высшая стадия!')+'</span></div>'+
    '<div class="dock-wallet"><div class="row" style="gap:8px">'+
      '<span class="pill star" title="Звёзды: за развивающие игры">'+STAR+'<span class="num">'+w.stars+'</span></span>'+
      '<span class="pill sunp" title="Солнышки: за дела в реальной жизни">'+SUN+'<span class="num">'+w.suns+'</span></span></div>'+
      '<a class="goal small" href="'+ROOT+'child/gifts.html"><span>Цель недели: <b class="num">'+Math.min(w.weekSuns,g.target)+' / '+g.target+' ☀</b></span><div class="bar"><span style="width:'+Math.min(100,w.weekSuns/g.target*100)+'%"></span></div></a></div>'+
    '<a class="lock" href="'+ROOT+'parent/gate.html#home" aria-label="Для родителей">'+ico24('lock')+'Для родителей</a>'+
  '</div>';
}
function tabbarHTML(tabs,active,badges){
  return '<nav aria-label="Разделы">'+tabs.map(t=>'<a href="'+ROOT+t[3]+'" class="'+(t[0]===active?'on':'')+'"'+(t[0]===active?' aria-current="page"':'')+'>'+ico24(t[2])+'<span>'+t[1]+'</span>'+((badges&&badges[t[0]])?'<span class="badge">'+badges[t[0]]+'</span>':'')+'</a>').join('')+'</nav>';
}
window.ChildShell={
  mount(opts){
    document.body.classList.add('child');
    if(opts.dock!==false){const slot=document.getElementById('dock-slot');if(slot)slot.innerHTML=dockHTML()}
    if(opts.tabs!==false){
      const t=document.createElement('div');t.className='tabbar';
      const d=DB(),todo=d.tasks.filter(x=>x.date===B.todayKey()&&x.status==='todo'&&x.kind==='real').length;
      t.innerHTML=tabbarHTML(CHILD_TABS,opts.tab,{gifts:todo});document.body.appendChild(t);
    }else document.body.classList.add('no-tabs');
    B.devbar();B.popFlash();
  },
  refreshDock(){const slot=document.getElementById('dock-slot');if(slot)slot.innerHTML=dockHTML()}
};

/* ---------------- PARENT ---------------- */
const PARENT_TABS=[
  ['home','Аналитика','chart','parent/index.html'],
  ['tasks','Задания','list','parent/tasks.html'],
  ['rewards','Подарки и цель','giftT','parent/rewards.html'],
  ['settings','Настройки','cog','parent/settings.html']
];
window.ParentShell={
  mount(opts){
    document.body.classList.add('parent');
    const d=DB(),p=Api.pending(),onChildDevice=!!B.AUTH().childDevice;
    const h=document.createElement('header');h.className='phead';
    h.innerHTML='<div class="in"><a class="brand" href="'+ROOT+'parent/index.html">'+LOGO+'<span>Брейни</span></a>'+
      '<span class="kid"><span class="av">'+brainy(d.stats,'kidav',d.acc)+'</span>'+esc(d.child.name)+', '+d.child.age+' лет</span>'+
      '<button class="btn sm '+(onChildDevice?'coral':'ghost')+' childmode" id="to-child">'+(onChildDevice?'Вернуть ребёнку':'Режим ребёнка')+'</button></div>';
    document.body.prepend(h);
    const t=document.createElement('div');t.className='tabbar';
    t.innerHTML=tabbarHTML(PARENT_TABS,opts.tab,{tasks:p.tasks,rewards:p.gifts});document.body.appendChild(t);
    h.querySelector('#to-child').addEventListener('click',()=>Auth.toChildMode());
    B.devbar();B.popFlash();
  }
};
})();
