#!/usr/bin/env python3
"""Brainy source launcher. Python 3.10+, standard library only. No app/DB writes."""
import argparse, concurrent.futures, hashlib, html, json, shutil, sys, tarfile, time
import urllib.parse, urllib.request, webbrowser, zipfile
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

HERE = Path(__file__).resolve().parent
CAT = json.loads((HERE/'catalog.json').read_text(encoding='utf-8'))
LOCK = json.loads((HERE/'sources.lock.json').read_text(encoding='utf-8'))
GAMES = {g['id']:g for g in CAT['games']}

def safe(root, relative):
    p = (root/relative).resolve()
    if not p.is_relative_to(root.resolve()): raise ValueError('Path escapes workspace: '+relative)
    return p

def download(url, destination, sha256=None):
    if destination.exists() and (not sha256 or hashlib.sha256(destination.read_bytes()).hexdigest()==sha256): return
    destination.parent.mkdir(parents=True, exist_ok=True)
    for attempt in range(3):
        try:
            req = urllib.request.Request(url, headers={'User-Agent':'Brainy-source-handoff/1'})
            with urllib.request.urlopen(req, timeout=60) as response: data=response.read()
            if sha256 and hashlib.sha256(data).hexdigest()!=sha256:
                raise ValueError('Archive checksum changed. Keep the pinned version; do not silently update the lock.')
            tmp=destination.with_suffix(destination.suffix+'.part'); tmp.write_bytes(data); tmp.replace(destination)
            return
        except Exception:
            if attempt==2: raise
            time.sleep(attempt+1)

def unpack(archive, destination):
    destination.mkdir(parents=True, exist_ok=True)
    if archive.name.endswith('.tgz'):
        with tarfile.open(archive) as t:
            for member in t.getmembers():
                target=safe(destination,member.name)
                if member.isfile():
                    target.parent.mkdir(parents=True,exist_ok=True)
                    with t.extractfile(member) as src, target.open('wb') as dst: shutil.copyfileobj(src,dst)
    else:
        with zipfile.ZipFile(archive) as z:
            for member in z.infolist():
                target=safe(destination,member.filename)
                if member.is_dir(): continue
                if (member.external_attr>>16)&0o170000==0o120000: raise ValueError('Archive contains a symlink')
                target.parent.mkdir(parents=True,exist_ok=True)
                with z.open(member) as src, target.open('wb') as dst: shutil.copyfileobj(src,dst)

def get_archive(key, work):
    item=LOCK['archives'][key]; dest=work/'downloads'/item['filename']
    bundled=HERE/'vendor-cache'/item['filename']
    if not dest.exists() and bundled.exists():
        dest.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(bundled,dest)
    download(item['url'],dest,item['sha256'])
    return dest

def prepare_repo(family, games, work, reuse, workers):
    spec=LOCK['repositories'][family]; dest=work/'public/vendor'/family
    prefixes=[g['sourcePrefix'] for g in games]
    files=[f for f in spec['files'] if f['common'] or any(f['path'].startswith(p) for p in prefixes)]
    def one(item):
        target=safe(dest,item['path'])
        def valid(p):
            if not p.exists() or p.stat().st_size!=item['size']: return False
            data=p.read_bytes()
            return hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==item['sha']
        if valid(target): return
        target.parent.mkdir(parents=True,exist_ok=True)
        source=Path(reuse)/item['path'] if reuse else None
        if source and valid(source): shutil.copy2(source,target)
        else:
            url=f"https://raw.githubusercontent.com/{spec['repo']}/{spec['commit']}/"+urllib.parse.quote(item['path'],safe='/')
            # Ignore an incomplete/mismatched previous file; the pinned Git blob is authoritative.
            temp=target.with_suffix(target.suffix+'.incoming')
            if temp.exists(): temp.unlink()
            download(url,temp)
            if not valid(temp): raise ValueError('Git blob checksum mismatch: '+item['path'])
            temp.replace(target)
    print(f'{family}: {len(files)} files; {sum(x["size"] for x in files)/1048576:.1f} MiB',flush=True)
    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as pool:
        for i,_ in enumerate(pool.map(one,files),1):
            if i%200==0: print(f'  {i}/{len(files)}',flush=True)
    if family=='sugarizer':
        # Compatibility patches only. Original repositories and their commits remain untouched.
        reflection=dest/'activities/Reflection.activity'
        if any(g.get('activity')=='Reflection' for g in games):
            p=reflection/'js/loader.js'; s=p.read_text(encoding='utf-8')
            s=s.replace('paths: {',"paths: {\n        'i18next.min': '../../../lib/i18next.min',\n        'axios.min': '../../../lib/axios.min',",1)
            p.write_text(s,encoding='utf-8')
            p=reflection/'index.html'; s=p.read_text(encoding='utf-8')
            s='\n'.join(line for line in s.splitlines() if 'fonts.googleapis.com' not in line)
            p.write_text(s,encoding='utf-8')
        if any(g.get('activity')=='FoodChain' for g in games):
            p=dest/'activities/FoodChain.activity/app.js'
            p.write_text(p.read_text(encoding='utf-8').replace('http://server.sugarizer.org/activities/FoodChain.activity/',''),encoding='utf-8')
        if any(g.get('activity')=='Exerciser' for g in games):
            unpack(get_archive('exerciser-source',work),work/'editable-sources/exerciser')

def prepare_h5p(game,work):
    kind=game['h5p']; public=work/'public'; root=public/'h5p'/game['id']
    unpack(get_archive('h5p-player',work),work/'player-package')
    shutil.copytree(work/'player-package/package/dist',public/'vendor/h5p-player',dirs_exist_ok=True)
    content=root/'package'; unpack(get_archive('h5p-'+kind,work),content)
    main=next(content.glob('H5P.'+kind+'-*/library.json'))
    library=json.loads(main.read_text(encoding='utf-8'))
    deps=[]; visited=set()
    def visit(lib):
        name=f"{lib['machineName']}-{lib['majorVersion']}.{lib['minorVersion']}"
        if name in visited:return
        visited.add(name)
        data=json.loads((content/name/'library.json').read_text(encoding='utf-8'))
        for child in data.get('preloadedDependencies',[]):visit(child)
        deps.append({k:lib[k] for k in ['machineName','majorVersion','minorVersion']})
    visit(library)
    meta={'title':game['title'],'language':'en','mainLibrary':library['machineName'],'embedTypes':['iframe'],'preloadedDependencies':deps,'license':'U'}
    (content/'h5p.json').write_text(json.dumps(meta),encoding='utf-8')
    shutil.copytree(HERE/'starter-content'/game['id'],content/'content',dirs_exist_ok=True)
    (root/'index.html').write_text('''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>'''+html.escape(game['title'])+'''</title><body><div id="h5p-container"></div><script src="../../vendor/h5p-player/main.bundle.js"></script><script>
    const base=new URL('.',location.href); window.h5pEvents=[];
    new H5PStandalone.H5P(document.getElementById('h5p-container'),{h5pJsonPath:new URL('package',base).href,frameJs:new URL('../../vendor/h5p-player/frame.bundle.js',base).href,frameCss:new URL('../../vendor/h5p-player/styles/h5p.css',base).href}).then(()=>{
      H5P.externalDispatcher.on('xAPI',e=>window.h5pEvents.push(e.data.statement));
    }).catch(e=>{document.body.append('Content failed to load: '+e.message);console.error(e)});
    </script></body></html>''',encoding='utf-8')
    key={'DragText':'dragtext-source','SortParagraphs':'sortparagraphs-source','Dictation':'dictation-source'}[kind]
    unpack(get_archive(key,work),work/'editable-sources'/game['id'])

def write_index(work):
    public=work/'public'; public.mkdir(parents=True,exist_ok=True)
    prepared=[]
    for game in GAMES.values():
        if (public/game['entry'].split('?')[0]).exists():prepared.append(game)
    (public/'catalog.json').write_text(json.dumps({'games':prepared},ensure_ascii=False,indent=2),encoding='utf-8')
    cards=''.join(f'<li><a href="play.html?id={g["id"]}">{g["number"]}. {html.escape(g["title"])}</a> — {html.escape(g["age"])} · {g["family"]}</li>' for g in prepared)
    (public/'index.html').write_text('<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Brainy source previews</title><style>body{font:17px system-ui;max-width:1000px;margin:40px auto;padding:20px}li{margin:14px 0}a{color:#176457}</style><h1>Brainy: source previews</h1><p>Original games and starter content. No Brainy rewards or progress integration.</p><ol style="list-style:none;padding:0">'+cards+'</ol></html>',encoding='utf-8')
    (public/'play.html').write_text('''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Brainy game preview</title><style>html,body{margin:0;height:100%;font:14px system-ui}header{height:48px;display:flex;align-items:center;gap:24px;padding:0 16px;background:#eee}iframe{width:100%;height:calc(100% - 48px);border:0;display:block}</style><header><a href="./">All games</a><strong id="name">Loading…</strong><span>Source preview · no rewards</span></header><iframe id="game" title="Learning game" sandbox="allow-scripts allow-same-origin allow-downloads allow-modals" allow="microphone; autoplay"></iframe><script>
    (async()=>{const id=new URLSearchParams(location.search).get('id');const {games}=await(await fetch('./catalog.json')).json();const g=games.find(g=>g.id===id);if(!g){document.getElementById('name').textContent='Game is not prepared. Run prepare '+id;return}
    document.getElementById('name').textContent=g.title;
    if(g.family==='sugarizer'){let user={};try{user=JSON.parse(localStorage.getItem('sugar_settings')||'{}')}catch{};localStorage.setItem('sugar_settings',JSON.stringify({...user,name:'Brainy Preview',language:'en',color:0,colorvalue:{stroke:'#005FE4',fill:'#FF2B34'},networkId:null,server:null,options:{stats:false},favorites:[],activities:games.filter(x=>x.sugarActivity).map(x=>x.sugarActivity)}))}
    document.getElementById('game').src=new URL(g.entry,location.href).href;
    })().catch(e=>document.getElementById('name').textContent=e.message);
    </script></html>''',encoding='utf-8')
    return len(prepared)

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('command',choices=['list','prepare','serve','export'])
    p.add_argument('game',nargs='?',default='all',help='Exact catalog id or all')
    p.add_argument('--workspace',type=Path,default=Path.cwd()/'.brainy-games')
    p.add_argument('--reuse-qlobe',type=Path);p.add_argument('--reuse-sugarizer',type=Path)
    p.add_argument('--workers',type=int,default=8);p.add_argument('--port',type=int,default=8070)
    p.add_argument('--open',action='store_true');p.add_argument('--to',type=Path)
    args=p.parse_args();work=args.workspace.resolve()
    if args.game!='all' and args.game not in GAMES:p.error('Unknown id; run list')
    if args.command=='list':
        for g in GAMES.values():print(f'{g["number"]:02} {g["id"]:26} {g["family"]:10} {g["title"]}')
        return
    if args.command=='prepare':
        selected=list(GAMES.values()) if args.game=='all' else [GAMES[args.game]]
        for family in ['qlobe','sugarizer']:
            subset=[g for g in selected if g['family']==family]
            if subset:prepare_repo(family,subset,work,getattr(args,'reuse_'+family),max(1,min(16,args.workers)))
        for game in selected:
            if game['family']=='h5p':prepare_h5p(game,work)
            elif game['family']=='blockly':
                unpack(get_archive('blockly-runtime',work),work/'public/vendor/blockly')
                unpack(get_archive('blockly-source',work),work/'editable-sources/blockly')
        print(f'Ready: {write_index(work)} entries. Preview: python launch_games.py serve --workspace "{work}" --open')
    elif args.command=='serve':
        if not (work/'public/catalog.json').exists():p.error('Run prepare first')
        route='/' if args.game=='all' else '/play.html?id='+args.game
        url=f'http://127.0.0.1:{args.port}'+route
        server=ThreadingHTTPServer(('127.0.0.1',args.port),partial(SimpleHTTPRequestHandler,directory=str(work/'public')))
        print(url,flush=True)
        if args.open:webbrowser.open(url)
        try:server.serve_forever()
        except KeyboardInterrupt:server.server_close()
    else:
        if not args.to:p.error('export requires --to <new-directory>')
        if not (work/'public/catalog.json').exists():p.error('Run prepare first')
        if args.to.exists():p.error('Export target must be a new directory; existing files will not be overwritten')
        shutil.copytree(work/'public',args.to)
        print('Exported static preview to',args.to.resolve())

if __name__=='__main__':
    try:main()
    except Exception as e:print('ERROR:',e,file=sys.stderr);sys.exit(1)
